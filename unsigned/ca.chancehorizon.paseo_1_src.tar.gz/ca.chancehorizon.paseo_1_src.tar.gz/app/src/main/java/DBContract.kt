package ca.chancehorizon.paseo

import android.provider.BaseColumns

object DBContract {

    /* Inner class that defines the table contents */
    class UserEntry : BaseColumns {
        companion object {
            val TABLE_NAME = "hours"
            val COLUMN_DATE_ID = "_id"
            val COLUMN_DATE = "date"
            val COLUMN_TIME = "hour"
            val COLUMN_STARTSTEPS = "startSteps"
            val COLUMN_ENDSTEPS = "endSteps"
        }
    }
}