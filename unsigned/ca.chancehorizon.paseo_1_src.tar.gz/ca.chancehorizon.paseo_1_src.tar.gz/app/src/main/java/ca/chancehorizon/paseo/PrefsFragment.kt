package ca.chancehorizon.paseo

import android.os.Bundle
import android.view.View
import android.widget.FrameLayout
import androidx.preference.Preference
import androidx.preference.PreferenceFragmentCompat
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog


class PrefsFragment : PreferenceFragmentCompat() {



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }



    override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
        setPreferencesFromResource(R.xml.paseo_settings, rootKey);
    }



    override fun onPreferenceTreeClick(preference: Preference?): Boolean {

        val key = preference!!.key

        // show the paseo about bottomsheet (which is also shown on "first run"
        if (key == "prefAbout") { // do your work
            val view: View = layoutInflater.inflate(R.layout.paseo_welcome_bottomsheet, null)

            val aboutPaseoBottomSheet = BottomSheetDialog(context!!)
            aboutPaseoBottomSheet.setContentView(view)
            aboutPaseoBottomSheet.show()
            val bottomSheet = aboutPaseoBottomSheet.findViewById<View>(R.id.design_bottom_sheet) as FrameLayout
            val bottomSheetBehavior = BottomSheetBehavior.from(bottomSheet)
            bottomSheetBehavior.state = BottomSheetBehavior.STATE_EXPANDED
        }

        // show the paseo license bottomsheet
        if (key == "prefLicense") { // do your work
            val view: View = layoutInflater.inflate(R.layout.paseo_license_bottomsheet, null)

            val aboutPaseoBottomSheet = BottomSheetDialog(context!!)
            aboutPaseoBottomSheet.setContentView(view)
            aboutPaseoBottomSheet.show()
            val bottomSheet = aboutPaseoBottomSheet.findViewById<View>(R.id.design_bottom_sheet) as FrameLayout
            val bottomSheetBehavior = BottomSheetBehavior.from(bottomSheet)
            bottomSheetBehavior.state = BottomSheetBehavior.STATE_EXPANDED
        }

        return super.onPreferenceTreeClick(preference)
    }



    override fun onDisplayPreferenceDialog(preference: Preference?) {
        val theDialog = preference as? OptionDialogPreference

        if (theDialog != null) {
            val dialogFragment = DialogPrefCompat.newInstance(theDialog.key)

            dialogFragment.setTargetFragment(this, 0)

            dialogFragment.positiveResult = {}

            val theFragmentManager = fragmentManager!!
            dialogFragment.show(theFragmentManager, null)
        }
        else
        {
            super.onDisplayPreferenceDialog(preference)
        }
    }
}