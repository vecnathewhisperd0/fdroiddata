package ca.chancehorizon.paseo.background

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.IBinder
import android.widget.RemoteViews
import android.widget.Toast
import androidx.annotation.Nullable
import androidx.core.app.NotificationCompat
import ca.chancehorizon.paseo.*
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.max


class StepCounterService : Service(), SensorEventListener {

    private val SERVICE_ID = 1001

    var running = false
    var sensorManager: SensorManager? = null
    var startSteps = 0
    var currentSteps = 0
    var endSteps = 0
    val targetSteps = 10000
    var latestDay = 0
    var latestHour = 0

    lateinit var paseoDBHelper : PaseoDBHelper


    @Nullable
    override fun onBind(intent: Intent): IBinder? {
        return null
    }


    override fun onCreate() {
        super.onCreate()

        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager

        running = true
        var stepsSensor = sensorManager?.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)

        if (stepsSensor == null) {
            Toast.makeText(this, "No Step Counter Sensor !", Toast.LENGTH_SHORT).show()
        } else {
            sensorManager?.registerListener(this, stepsSensor, SensorManager.SENSOR_DELAY_UI)
        }

        // point to the Paseo database that stores all the daily steps data
        paseoDBHelper = PaseoDBHelper(this)
    }



    override fun onDestroy() {
        super.onDestroy()

        stopForeground(true)

        val broadcastIntent = Intent()
        broadcastIntent.action = "restartservice"
        broadcastIntent.setClass(this, Restarter::class.java)
        this.sendBroadcast(broadcastIntent)

    }



    override fun onTaskRemoved(rootIntent: Intent?) {
        super.onTaskRemoved(rootIntent)
        stopSelf()
    }



    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForegroundServiceWithNotification()

        return Service.START_STICKY
        //return super.onStartCommand(intent, flags, startId)
    }



    private fun startForegroundServiceWithNotification() {
        val intent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT)

        val builder: NotificationCompat.Builder
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channelName = getString(R.string.notification_channel_step_count)
            val importance = NotificationManager.IMPORTANCE_LOW
            val channelId = "PASEO_CHANNEL_ID"
            val channel = NotificationChannel(channelId, channelName, importance)
            channel.setShowBadge(true)

            builder = NotificationCompat.Builder(this, channelId)

            val notificatioManager = getSystemService(NotificationManager::class.java)
            notificatioManager.createNotificationChannel(channel)
        } else {
            builder = NotificationCompat.Builder(this)
        }

        val icon = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) R.mipmap.ic_launcher_nb else R.mipmap.ic_notification

        var DateFormat = SimpleDateFormat("yyyyMMdd") // looks like "19891225"
        val today = DateFormat.format(Date()).toInt()

        // if currentSteps > startSteps then
        //  do not need to create a new record
        val theSteps = paseoDBHelper.getDaysSteps(today)

        with(builder) {
            builder.setContentTitle("" + NumberFormat.getIntegerInstance().format(theSteps) + " steps today. ");
            builder.setStyle(NotificationCompat.BigTextStyle().bigText("Target: " +
                    NumberFormat.getIntegerInstance().format(targetSteps) + ". " +
                    NumberFormat.getIntegerInstance().format(max(targetSteps - theSteps, 0)) +
                    " to go! "))
            setWhen(System.currentTimeMillis())
            setSmallIcon(icon)
            setContentIntent(pendingIntent)
            priority = NotificationCompat.PRIORITY_LOW
            setVisibility(NotificationCompat.VISIBILITY_SECRET)
        }

        val notification = builder.build()

        startForeground(SERVICE_ID, notification)
    }



    override fun onAccuracyChanged(p0: Sensor?, p1: Int)
    {
    }



    // override fun onSensorChanged(event: SensorEvent)
    override fun onSensorChanged(event: SensorEvent)
    {

        if (running)
        {
            var DateFormat = SimpleDateFormat("yyyyMMdd") // looks like "19891225"
            val today = DateFormat.format(Date()).toInt()
            DateFormat = SimpleDateFormat("HH")
            val currentHour = DateFormat.format(Date()).toInt()

            // read the step count value from the devices step counter sensor
            currentSteps = event.values[0].toInt()

            // get the latest step information from the database
            if (paseoDBHelper.readRowCount() > 0) {
                latestDay = paseoDBHelper.readLastStepsDate();
                latestHour = paseoDBHelper.readLastStepsTime();
                startSteps = paseoDBHelper.readLastStartSteps();
                endSteps = paseoDBHelper.readLastEndSteps();
            }

            // hour is one more than last hour recorded -> add new hour record to database
            if(today == latestDay && currentHour == latestHour + 1 && currentSteps >= startSteps) {
                addSteps(today, currentHour, endSteps, currentSteps);
            }
            // add a new hour record (may be for current day or for a new day)
            //  also add a new record if the current steps is less than the most recent start steps (happens when phone has been rebooted)
            else if (today != latestDay || currentHour != latestHour || currentSteps < startSteps) {
                addSteps(today, currentHour, currentSteps, currentSteps);
            }
            else {
                //  set endSteps to current steps (update the end steps for current hour)
                addSteps(today, currentHour, 0, currentSteps, true)
            }

            // if currentSteps > startSteps then
            //  do not need to create a new record
            val theSteps = paseoDBHelper.getDaysSteps(today)

            // update the step count in the widget
            val context = this
            val appWidgetManager = AppWidgetManager.getInstance(context)
            val remoteViews = RemoteViews(context.packageName, R.layout.paseo_steps_widget)
            val thisWidget = ComponentName(context, PaseoStepsWidget::class.java)
            remoteViews.setTextViewText(R.id.stepwidget_text, "" + NumberFormat.getIntegerInstance().format(theSteps))
            appWidgetManager.updateAppWidget(thisWidget, remoteViews)

            // update the notification with new step count
            val builder: NotificationCompat.Builder
            val channelId = "PASEO_CHANNEL_ID"

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channelName = getString(R.string.notification_channel_step_count)
                val importance = NotificationManager.IMPORTANCE_LOW
                val channel = NotificationChannel(channelId, channelName, importance)
                val notificationManager = getSystemService(NotificationManager::class.java)
                val icon = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) R.mipmap.ic_launcher_nb else R.mipmap.ic_notification

                builder = NotificationCompat.Builder(this, channelId)
                builder.setContentTitle("" + NumberFormat.getIntegerInstance().format(theSteps) + " steps today. ");
                builder.setStyle(NotificationCompat.BigTextStyle().bigText("Target: " +
                        NumberFormat.getIntegerInstance().format(targetSteps) + " . " +
                        NumberFormat.getIntegerInstance().format(max(targetSteps - theSteps, 0)) +
                        " to go! "))
                builder.setSmallIcon(icon)

                try {
                    notificationManager.notify(SERVICE_ID, builder.build());
                }
                catch (e : Exception)
                {
                    print (e)
                }
            }
            // send message to application activity so that it can react to new steps being sensed
            val local = Intent()

            local.action = "ca.chancehorizon.paseo.action"
            local.putExtra("data", theSteps)
            this.sendBroadcast(local)
        }

    }



    // insert or update a steps record in the Move database
    fun addSteps(date: Int = 0, time: Int = 0, startSteps: Int = 0, endSteps: Int = 0, update: Boolean = false)
    {

        // update the endsteps for the current hour
        if (update)
        {
            var result = paseoDBHelper.updateEndSteps(StepsModel(0, date = date, hour = time,
                    startSteps = startSteps, endSteps = endSteps))
        }
        else
        {
            var result = paseoDBHelper.insertSteps(StepsModel(0, date = date, hour = time,
                    startSteps = startSteps, endSteps = endSteps))
        }

        latestDay = date
    }

}
