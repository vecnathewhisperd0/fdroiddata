package ca.chancehorizon.paseo


import android.content.Context
import android.util.AttributeSet
import androidx.preference.DialogPreference



class OptionDialogPreference(context: Context, attrs: AttributeSet?) : DialogPreference(context, attrs){

}

