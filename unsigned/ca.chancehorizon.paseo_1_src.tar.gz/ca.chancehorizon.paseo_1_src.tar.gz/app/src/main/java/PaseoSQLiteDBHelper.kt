package ca.chancehorizon.paseo


import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteConstraintException
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteException
import android.database.sqlite.SQLiteOpenHelper
import android.text.TextUtils.substring
import java.text.SimpleDateFormat
import java.util.*


class PaseoDBHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION)
{
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(SQL_CREATE_ENTRIES)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // This database upgrade policy is
        // simply to discard the data and start over
        db.execSQL(SQL_DELETE_ENTRIES)
        onCreate(db)
    }

    override fun onDowngrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        onUpgrade(db, oldVersion, newVersion)
    }

    @Throws(SQLiteConstraintException::class)
    fun insertSteps(hours: StepsModel): Boolean {
        // Gets the data repository in write mode
        val db = writableDatabase

        // Create a new map of values, where column names are the keys
        val values = ContentValues()
        values.put(DBContract.UserEntry.COLUMN_DATE, hours.date)
        values.put(DBContract.UserEntry.COLUMN_TIME, hours.hour)
        values.put(DBContract.UserEntry.COLUMN_STARTSTEPS, hours.startSteps)
        values.put(DBContract.UserEntry.COLUMN_ENDSTEPS, hours.endSteps)

        // Insert the new row, returning the primary key value of the new row
        val newRowId = db.insert(DBContract.UserEntry.TABLE_NAME, null, values)

        return true
    }


    @Throws(SQLiteConstraintException::class)
    fun updateEndSteps(steps: StepsModel): Boolean {
        // Gets the data repository in write mode
        val db = writableDatabase

        var rowID = 0
        var cursor: Cursor? = null

        try {
            cursor = db.rawQuery("SELECT " + DBContract.UserEntry.COLUMN_DATE_ID + " FROM " + DBContract.UserEntry.TABLE_NAME +
                    " ORDER BY " + DBContract.UserEntry.COLUMN_DATE_ID + " DESC LIMIT 1", null)
        } catch (e: SQLiteException) {
            return false
        }

        if (cursor!!.moveToFirst()) {
            rowID = cursor.getInt(cursor.getColumnIndex(DBContract.UserEntry.COLUMN_DATE_ID))
        }

        try {
            db.execSQL("UPDATE " + DBContract.UserEntry.TABLE_NAME + " SET " + DBContract.UserEntry.COLUMN_ENDSTEPS + " = " + steps.endSteps +
                    " WHERE " + DBContract.UserEntry.COLUMN_DATE_ID + " = " + rowID)
        } catch (e: SQLiteException) {
            // if table not yet present, create it
            db.execSQL(SQL_CREATE_ENTRIES)
            return false
        }

        cursor.close()
        return true
    }


    @Throws(SQLiteConstraintException::class)
    fun deleteSteps(stepsId: String): Boolean {
        // Gets the data repository in write mode
        val db = writableDatabase
        // Define 'where' part of query.
        val selection = DBContract.UserEntry.COLUMN_DATE_ID + " LIKE ?"
        // Specify arguments in placeholder order.
        val selectionArgs = arrayOf(stepsId)
        // Issue SQL statement.
        db.delete(DBContract.UserEntry.TABLE_NAME, selection, selectionArgs)

        return true
    }


    // retrieve records from Move database for a specific date
    fun readSteps(date: Int): ArrayList<StepsModel> {
        val steps = ArrayList<StepsModel>()
        val db = writableDatabase
        var cursor: Cursor? = null
        try {
            cursor = db.rawQuery("select * from " + DBContract.UserEntry.TABLE_NAME + " WHERE " + DBContract.UserEntry.COLUMN_DATE + "='" + date + "'", null)
        } catch (e: SQLiteException) {
            // if table not yet present, create it
            db.execSQL(SQL_CREATE_ENTRIES)
            return ArrayList()
        }

        var stepsId: Int
        var time: Int
        var startSteps: Int
        var endSteps: Int
        if (cursor!!.moveToFirst()) {
            while (cursor.isAfterLast == false) {
                stepsId = cursor.getInt(cursor.getColumnIndex(DBContract.UserEntry.COLUMN_TIME))
                time = cursor.getInt(cursor.getColumnIndex(DBContract.UserEntry.COLUMN_TIME))
                startSteps = cursor.getInt(cursor.getColumnIndex(DBContract.UserEntry.COLUMN_STARTSTEPS))
                endSteps = cursor.getInt(cursor.getColumnIndex(DBContract.UserEntry.COLUMN_ENDSTEPS))

                steps.add(StepsModel(stepsId, date, time, startSteps, endSteps))
                cursor.moveToNext()
            }
        }

        cursor.close()
        return steps
    }


    // get the number of steps taken in each hour of a day
    fun getDaysSteps(date: Int): Int {

        var daySteps = 0
        val db = writableDatabase
        var cursor: Cursor? = null

        try {
            cursor = db.rawQuery("SELECT SUM(" + DBContract.UserEntry.COLUMN_ENDSTEPS + " - " +
                    DBContract.UserEntry.COLUMN_STARTSTEPS + ") AS sumSteps " +
                    " FROM " + DBContract.UserEntry.TABLE_NAME +
                    " WHERE " + DBContract.UserEntry.COLUMN_DATE + " = " + date +
                    " GROUP BY " + DBContract.UserEntry.COLUMN_DATE + "", null)
        } catch (e: SQLiteException) {
            return daySteps
        }

        if (cursor!!.moveToFirst()) {
            daySteps = cursor.getInt(0)
        }

        cursor.close()
        return daySteps
    }


    // get the number of steps taken in each hour of a day (or day of year, or week of year, or month of year)
    fun getStepsByTimeUnit(date: Int, timeUnit: String, asc: Boolean = true): ArrayList<Array<Int>> {

        var daySteps = ArrayList<Array<Int>>()
        val db = writableDatabase
        var cursor: Cursor? = null
        var theQuery = ""

        when (timeUnit) {
            "hours" -> {
               theQuery = "SELECT " + DBContract.UserEntry.COLUMN_TIME + ", SUM(" + DBContract.UserEntry.COLUMN_ENDSTEPS + " - " +
                       DBContract.UserEntry.COLUMN_STARTSTEPS + ") AS sumSteps " +
                       " FROM " + DBContract.UserEntry.TABLE_NAME +
                       " WHERE " + DBContract.UserEntry.COLUMN_DATE + " = " + date +
                       " GROUP BY " + DBContract.UserEntry.COLUMN_DATE + ", " + DBContract.UserEntry.COLUMN_TIME + ""
            }
            "days" -> {
                theQuery = "SELECT " + DBContract.UserEntry.COLUMN_DATE + ", SUM(" + DBContract.UserEntry.COLUMN_ENDSTEPS + " - " +
                        DBContract.UserEntry.COLUMN_STARTSTEPS + ") AS sumSteps " +
                        " FROM " + DBContract.UserEntry.TABLE_NAME +
                        " GROUP BY " + DBContract.UserEntry.COLUMN_DATE // +
            }
            "weeks" -> {
                val dateFormat = SimpleDateFormat("w")
                val theWeek = dateFormat.format(date)
                theQuery = "SELECT " +
                        " CAST(STRFTIME('%W', DATE(SUBSTR(" + DBContract.UserEntry.COLUMN_DATE + ", 1, 4) || '-'" +
                        " || SUBSTR(" + DBContract.UserEntry.COLUMN_DATE + ", 5, 2) || '-'" +
                        " || SUBSTR(" + DBContract.UserEntry.COLUMN_DATE + ", 7, 2))) AS int) AS week " +
                        ", SUM(" + DBContract.UserEntry.COLUMN_ENDSTEPS + " - " +
                        DBContract.UserEntry.COLUMN_STARTSTEPS + ") AS sumSteps " +
                        " FROM " + DBContract.UserEntry.TABLE_NAME +
                        " GROUP BY week"
            }
            "months" -> {
                theQuery = "SELECT " +
                        " CAST(SUBSTR(" + DBContract.UserEntry.COLUMN_DATE + ", 5, 2) AS INT) AS month " +
                        ", SUM(" + DBContract.UserEntry.COLUMN_ENDSTEPS + " - " +
                        DBContract.UserEntry.COLUMN_STARTSTEPS + ") AS sumSteps " +
                        " FROM " + DBContract.UserEntry.TABLE_NAME +
                        " GROUP BY month"
            }
            "years" -> {
                theQuery = "SELECT " +
                        " CAST(SUBSTR(" + DBContract.UserEntry.COLUMN_DATE + ", 1, 4) AS INT) AS year " +
                        ", SUM(" + DBContract.UserEntry.COLUMN_ENDSTEPS + " - " +
                        DBContract.UserEntry.COLUMN_STARTSTEPS + ") AS sumSteps " +
                        " FROM " + DBContract.UserEntry.TABLE_NAME +
                        " GROUP BY year"
            }
        }
        try {
            cursor = db.rawQuery(theQuery, null)
        } catch (e: SQLiteException) {
            return daySteps
        }

        // create an arrayList storing the steps by hour for this day
        if (cursor != null && cursor.moveToFirst()) {

            //add row to list
            do {
                daySteps.add(arrayOf(cursor.getInt(0), cursor.getInt(1)))
            }
            while (cursor.moveToNext())
            cursor.close()
        }

        cursor.close()
        return daySteps
    }



    // retrieve number of records from Move database
    fun readRowCount(): Int {
        var numRows = 0
        val db = writableDatabase
        var cursor: Cursor? = null
        try {
            cursor = db.rawQuery("SELECT COUNT(*) FROM " + DBContract.UserEntry.TABLE_NAME , null)
        } catch (e: SQLiteException) {
            // if table not yet present, create it
            db.execSQL(SQL_CREATE_ENTRIES)
            return numRows
        }

        if (cursor!!.moveToFirst()) {
            numRows = cursor.getInt(0)
        }
        cursor.close()
        return numRows
    }



    // retrieve most recent steps date in the Move database
    fun readLastStepsDate(): Int {
        var date = 0
        val db = writableDatabase
        var cursor: Cursor? = null
        try {
            cursor = db.rawQuery("SELECT " + DBContract.UserEntry.COLUMN_DATE + " FROM " + DBContract.UserEntry.TABLE_NAME +
                    " ORDER BY " + DBContract.UserEntry.COLUMN_DATE_ID + " DESC LIMIT 1", null)
        } catch (e: SQLiteException) {
            // if table not yet present, create it
            db.execSQL(SQL_CREATE_ENTRIES)
            return date
        }

        if (cursor!!.moveToFirst()) {
            date = cursor.getInt(cursor.getColumnIndex(DBContract.UserEntry.COLUMN_DATE))
        }

        cursor.close()
        return date
    }



    // retrieve most recent steps time in the Move database
    fun readLastStepsTime(): Int {
        var time = 0
        val db = writableDatabase
        var cursor: Cursor? = null
        try {
            cursor = db.rawQuery("SELECT " + DBContract.UserEntry.COLUMN_TIME + " FROM " + DBContract.UserEntry.TABLE_NAME +
                    " ORDER BY " + DBContract.UserEntry.COLUMN_DATE_ID + " DESC LIMIT 1", null)
        } catch (e: SQLiteException) {
            // if table not yet present, create it
            db.execSQL(SQL_CREATE_ENTRIES)
            return time
        }

        if (cursor!!.moveToFirst()) {
            time = cursor.getInt(cursor.getColumnIndex(DBContract.UserEntry.COLUMN_TIME))
        }

        cursor.close()
        return time
    }



    // retrieve most recent steps date in the Move database
    fun readLastStartSteps(): Int {
        var startSteps = 0
        val db = writableDatabase
        var cursor: Cursor? = null
        try {
            cursor = db.rawQuery("SELECT " + DBContract.UserEntry.COLUMN_STARTSTEPS + " from " + DBContract.UserEntry.TABLE_NAME +
                    " ORDER BY " + DBContract.UserEntry.COLUMN_DATE_ID + " DESC LIMIT 1", null)
        } catch (e: SQLiteException) {
            // if table not yet present, create it
            db.execSQL(SQL_CREATE_ENTRIES)
            return startSteps
        }

        if (cursor!!.moveToFirst()) {
            startSteps = cursor.getInt(cursor.getColumnIndex(DBContract.UserEntry.COLUMN_STARTSTEPS))
        }

        cursor.close()
        return startSteps
    }



    // retrieve most recent end steps in the Move database
    fun readLastEndSteps(): Int {
        var endSteps = 0
        val db = writableDatabase
        var cursor: Cursor? = null
        try {
            cursor = db.rawQuery("SELECT " + DBContract.UserEntry.COLUMN_ENDSTEPS + " from " + DBContract.UserEntry.TABLE_NAME +
                    " ORDER BY " + DBContract.UserEntry.COLUMN_DATE_ID + " DESC LIMIT 1", null)
        } catch (e: SQLiteException) {
            // if table not yet present, create it
            db.execSQL(SQL_CREATE_ENTRIES)
            return endSteps
        }

        if (cursor!!.moveToFirst()) {
            endSteps = cursor.getInt(cursor.getColumnIndex(DBContract.UserEntry.COLUMN_ENDSTEPS))
        }

        cursor.close()
        return endSteps
    }



    // retrieve the total number of steps taken in timeUnit (day, week,...)
    fun getSteps(timeUnit: String, theDate: Int, theDay: Int = 0): Int {
        var theSteps = 0
        val db = writableDatabase
        var cursor: Cursor? = null

        when (timeUnit) {
            "hours" -> {
                try {
                    cursor = db.rawQuery("SELECT SUM(" + DBContract.UserEntry.COLUMN_ENDSTEPS + " - " +
                            DBContract.UserEntry.COLUMN_STARTSTEPS + ") AS sumSteps " +
                            " FROM " + DBContract.UserEntry.TABLE_NAME +
                            " WHERE " + DBContract.UserEntry.COLUMN_TIME + " = " + theDate +
                            " AND " + DBContract.UserEntry.COLUMN_DATE + " = " + theDay +
                            " GROUP BY " + DBContract.UserEntry.COLUMN_TIME + "", null)
                } catch (e: SQLiteException) {
                    return theSteps
                }
            }

            "days" -> {
                try {
                    cursor = db.rawQuery("SELECT SUM(" + DBContract.UserEntry.COLUMN_ENDSTEPS + " - " +
                            DBContract.UserEntry.COLUMN_STARTSTEPS + ") AS sumSteps " +
                            " FROM " + DBContract.UserEntry.TABLE_NAME +
                            " WHERE " + DBContract.UserEntry.COLUMN_DATE + " = " + theDate +
                            " GROUP BY " + DBContract.UserEntry.COLUMN_DATE + "", null)
                } catch (e: SQLiteException) {
                    return theSteps
                }
            }

            "weeks"-> {
                val calendar = Calendar.getInstance()
                calendar.time = Date()
                // need to subtract one day from date (Kotlin starts week on Monday, SQLite starts week on Sunday)
                calendar.add(Calendar.DAY_OF_YEAR, -1);
                val theWeek = calendar.get(Calendar.WEEK_OF_YEAR) - 1

                try {
                    cursor = db.rawQuery("SELECT SUM(" + DBContract.UserEntry.COLUMN_ENDSTEPS + " - " +
                            DBContract.UserEntry.COLUMN_STARTSTEPS + ") AS sumSteps, " +
                            " CAST(STRFTIME('%W', DATE(SUBSTR(" + DBContract.UserEntry.COLUMN_DATE + ", 1, 4) || '-'" +
                            " || SUBSTR(" + DBContract.UserEntry.COLUMN_DATE + ", 5, 2) || '-'" +
                            " || SUBSTR(" + DBContract.UserEntry.COLUMN_DATE + ", 7, 2))) AS int) AS week " +
                            " FROM " + DBContract.UserEntry.TABLE_NAME +
                            " WHERE week = " + theWeek  +
                            " AND SUBSTR(" + DBContract.UserEntry.COLUMN_DATE + ", 1, 4) = '" + substring(theDate.toString(), 0, 4) + "'" +
                            " GROUP BY week ", null)
                } catch (e: SQLiteException) {
                    return theSteps
                }
            }

            "months" -> {
                try {
                    cursor = db.rawQuery("SELECT SUM(" + DBContract.UserEntry.COLUMN_ENDSTEPS + " - " +
                            DBContract.UserEntry.COLUMN_STARTSTEPS + ") AS sumSteps, " +
                            " CAST(SUBSTR(" + DBContract.UserEntry.COLUMN_DATE + ", 5, 2) AS INT) AS month " +
                            " FROM " + DBContract.UserEntry.TABLE_NAME +
                            " WHERE month = SUBSTR(" + theDate  + ", 5, 2) " +
                            " AND SUBSTR(" + DBContract.UserEntry.COLUMN_DATE + ", 1, 4) = '" + substring(theDate.toString(), 0, 4) + "'" +
                            " GROUP BY month ", null)
                } catch (e: SQLiteException) {
                    return theSteps
                }
            }
            "years" -> {
                try {
                    cursor = db.rawQuery("SELECT SUM(" + DBContract.UserEntry.COLUMN_ENDSTEPS + " - " +
                            DBContract.UserEntry.COLUMN_STARTSTEPS + ") AS sumSteps, " +
                            " CAST(SUBSTR(" + DBContract.UserEntry.COLUMN_DATE + ", 1, 4) AS INT) AS year " +
                            " FROM " + DBContract.UserEntry.TABLE_NAME +
                            " WHERE year = SUBSTR(" + theDate  + ", 1, 4) " +
                            " GROUP BY year ", null)
                } catch (e: SQLiteException) {
                    return theSteps
                }
            }
        }

        if (cursor!!.moveToFirst()) {
            theSteps = cursor.getInt(cursor.getColumnIndex("sumSteps"))
        }

        cursor.close()
        return theSteps
    }



    // retrieve the maximum number of steps taken in timeUnit (day, week,...)
    fun getMaxSteps(timeUnit: String, theDate: Int, theDay: Int = 0): Int {
        var endSteps = 0
        val db = writableDatabase
        var cursor: Cursor? = null

        when (timeUnit) {
            "hours" -> {
                return endSteps
            }
            "days" -> {
                try {
                    cursor = db.rawQuery("SELECT CAST(MAX(sumSteps) AS INTEGER) AS maxSteps " +
                            "FROM (SELECT SUM(" + DBContract.UserEntry.COLUMN_ENDSTEPS + " - " +
                            DBContract.UserEntry.COLUMN_STARTSTEPS + ") AS sumSteps FROM " +
                            DBContract.UserEntry.TABLE_NAME  +
                            " GROUP BY " + DBContract.UserEntry.COLUMN_DATE + ")", null)
                } catch (e: SQLiteException) {
                    return endSteps
                }
            }

            "weeks"-> {
                try {
                    cursor = db.rawQuery("SELECT CAST(MAX(sumSteps) AS INTEGER) AS maxSteps " +
                            "FROM (SELECT SUM(" + DBContract.UserEntry.COLUMN_ENDSTEPS + " - " +
                            DBContract.UserEntry.COLUMN_STARTSTEPS + ") AS sumSteps, " +
                            " CAST(STRFTIME('%W', DATE(SUBSTR(" + DBContract.UserEntry.COLUMN_DATE + ", 1, 4) || '-'" +
                            " || SUBSTR(" + DBContract.UserEntry.COLUMN_DATE + ", 5, 2) || '-'" +
                            " || SUBSTR(" + DBContract.UserEntry.COLUMN_DATE + ", 7, 2))) AS int) AS week " +
                            " FROM " + DBContract.UserEntry.TABLE_NAME +
                            " GROUP BY week )", null)

                } catch (e: SQLiteException) {
                    return endSteps
                }
            }
            "months" -> {
                try {
                    cursor = db.rawQuery("SELECT CAST(MAX(sumSteps) AS INTEGER) AS maxSteps " +
                            "FROM (SELECT SUM(" + DBContract.UserEntry.COLUMN_ENDSTEPS + " - " +
                            DBContract.UserEntry.COLUMN_STARTSTEPS + ") AS sumSteps, " +
                            " CAST(SUBSTR(" + DBContract.UserEntry.COLUMN_DATE + ", 5, 2) AS INT) AS month " +
                            " FROM " + DBContract.UserEntry.TABLE_NAME +
                            " GROUP BY month )", null)
                } catch (e: SQLiteException) {
                    return endSteps
                }
            }
            "years" -> {
                try {
                    cursor = db.rawQuery("SELECT CAST(MAX(sumSteps) AS INTEGER) AS maxSteps " +
                            "FROM (SELECT SUM(" + DBContract.UserEntry.COLUMN_ENDSTEPS + " - " +
                            DBContract.UserEntry.COLUMN_STARTSTEPS + ") AS sumSteps, " +
                            " CAST(SUBSTR(" + DBContract.UserEntry.COLUMN_DATE + ", 1, 4) AS INT) AS year " +
                            " FROM " + DBContract.UserEntry.TABLE_NAME +
                            " WHERE year = SUBSTR(" + theDate  + ", 1, 4) " +
                            " GROUP BY year )", null)
                } catch (e: SQLiteException) {
                    return endSteps
                }
            }
        }

        if (cursor!!.moveToFirst()) {
            endSteps = cursor.getInt(cursor.getColumnIndex("maxSteps"))
        }

        cursor.close()
        return endSteps
    }



    // retrieve the minimum number of steps taken in timeUnit (day, week,...)
    fun getMinSteps(timeUnit: String, theDate: Int, theDay: Int = 0): Int {
        var endSteps = 0
        val db = writableDatabase
        var cursor: Cursor? = null

        when (timeUnit) {
            "hours" -> {
                return endSteps
            }
            "days" -> {
                try {
                    cursor = db.rawQuery("SELECT CAST(MIN(sumSteps) AS INTEGER) AS maxSteps " +
                            "FROM (SELECT SUM(" + DBContract.UserEntry.COLUMN_ENDSTEPS + " - " +
                            DBContract.UserEntry.COLUMN_STARTSTEPS + ") AS sumSteps FROM " +
                            DBContract.UserEntry.TABLE_NAME  +
                            " GROUP BY " + DBContract.UserEntry.COLUMN_DATE + ")", null)
                } catch (e: SQLiteException) {
                    return endSteps
                }
            }

            "weeks"-> {
                try {
                    cursor = db.rawQuery("SELECT CAST(MIN(sumSteps) AS INTEGER) AS maxSteps " +
                            "FROM (SELECT SUM(" + DBContract.UserEntry.COLUMN_ENDSTEPS + " - " +
                            DBContract.UserEntry.COLUMN_STARTSTEPS + ") AS sumSteps, " +
                            " CAST(STRFTIME('%W', DATE(SUBSTR(" + DBContract.UserEntry.COLUMN_DATE + ", 1, 4) || '-'" +
                            " || SUBSTR(" + DBContract.UserEntry.COLUMN_DATE + ", 5, 2) || '-'" +
                            " || SUBSTR(" + DBContract.UserEntry.COLUMN_DATE + ", 7, 2))) AS int) AS week " +
                            " FROM " + DBContract.UserEntry.TABLE_NAME +
                            " GROUP BY week )", null)

                } catch (e: SQLiteException) {
                    return endSteps
                }
            }
            "months" -> {
                try {
                    cursor = db.rawQuery("SELECT CAST(MIN(sumSteps) AS INTEGER) AS maxSteps " +
                            "FROM (SELECT SUM(" + DBContract.UserEntry.COLUMN_ENDSTEPS + " - " +
                            DBContract.UserEntry.COLUMN_STARTSTEPS + ") AS sumSteps, " +
                            " CAST(SUBSTR(" + DBContract.UserEntry.COLUMN_DATE + ", 5, 2) AS INT) AS month " +
                            " FROM " + DBContract.UserEntry.TABLE_NAME +
                            " GROUP BY month )", null)
                } catch (e: SQLiteException) {
                    return endSteps
                }
            }
            "years" -> {
                try {
                    cursor = db.rawQuery("SELECT CAST(MIN(sumSteps) AS INTEGER) AS maxSteps " +
                            "FROM (SELECT SUM(" + DBContract.UserEntry.COLUMN_ENDSTEPS + " - " +
                            DBContract.UserEntry.COLUMN_STARTSTEPS + ") AS sumSteps, " +
                            " CAST(SUBSTR(" + DBContract.UserEntry.COLUMN_DATE + ", 1, 4) AS INT) AS year " +
                            " FROM " + DBContract.UserEntry.TABLE_NAME +
                            " WHERE year = SUBSTR(" + theDate  + ", 1, 4) " +
                            " GROUP BY year )", null)
                } catch (e: SQLiteException) {
                    return endSteps
                }
            }
        }

        if (cursor!!.moveToFirst()) {
            endSteps = cursor.getInt(cursor.getColumnIndex("maxSteps"))
        }

        cursor.close()
        return endSteps
    }



    // retrieve the average number of steps taken in timeUnit (day, week,...)
    fun getAverageSteps(timeUnit: String, theDate: Int, theDay: Int = 0): Int {
        var endSteps = 0
        val db = writableDatabase
        var cursor: Cursor? = null

        when (timeUnit) {
            "hours" -> {
                return endSteps
            }
            "days" -> {
                try {
                    cursor = db.rawQuery("SELECT CAST(AVG(sumSteps) AS INTEGER) AS maxSteps " +
                            "FROM (SELECT SUM(" + DBContract.UserEntry.COLUMN_ENDSTEPS + " - " +
                            DBContract.UserEntry.COLUMN_STARTSTEPS + ") AS sumSteps FROM " +
                            DBContract.UserEntry.TABLE_NAME  +
                            " GROUP BY " + DBContract.UserEntry.COLUMN_DATE + ")", null)
                } catch (e: SQLiteException) {
                    return endSteps
                }
            }

            "weeks"-> {
                try {
                    cursor = db.rawQuery("SELECT CAST(AVG(sumSteps) AS INTEGER) AS maxSteps " +
                            "FROM (SELECT SUM(" + DBContract.UserEntry.COLUMN_ENDSTEPS + " - " +
                            DBContract.UserEntry.COLUMN_STARTSTEPS + ") AS sumSteps, " +
                            " CAST(STRFTIME('%W', DATE(SUBSTR(" + DBContract.UserEntry.COLUMN_DATE + ", 1, 4) || '-'" +
                            " || SUBSTR(" + DBContract.UserEntry.COLUMN_DATE + ", 5, 2) || '-'" +
                            " || SUBSTR(" + DBContract.UserEntry.COLUMN_DATE + ", 7, 2))) AS int) AS week " +
                            " FROM " + DBContract.UserEntry.TABLE_NAME +
                            " GROUP BY week )", null)

                } catch (e: SQLiteException) {
                    return endSteps
                }
            }
            "months" -> {
                try {
                    cursor = db.rawQuery("SELECT CAST(AVG(sumSteps) AS INTEGER) AS maxSteps " +
                            "FROM (SELECT SUM(" + DBContract.UserEntry.COLUMN_ENDSTEPS + " - " +
                            DBContract.UserEntry.COLUMN_STARTSTEPS + ") AS sumSteps, " +
                            " CAST(SUBSTR(" + DBContract.UserEntry.COLUMN_DATE + ", 5, 2) AS INT) AS month " +
                            " FROM " + DBContract.UserEntry.TABLE_NAME +
                            " GROUP BY month )", null)
                } catch (e: SQLiteException) {
                    return endSteps
                }
            }
            "years" -> {
                try {
                    cursor = db.rawQuery("SELECT CAST(AVG(sumSteps) AS INTEGER) AS maxSteps " +
                            "FROM (SELECT SUM(" + DBContract.UserEntry.COLUMN_ENDSTEPS + " - " +
                            DBContract.UserEntry.COLUMN_STARTSTEPS + ") AS sumSteps, " +
                            " CAST(SUBSTR(" + DBContract.UserEntry.COLUMN_DATE + ", 1, 4) AS INT) AS year " +
                            " FROM " + DBContract.UserEntry.TABLE_NAME +
                            " WHERE year = SUBSTR(" + theDate  + ", 1, 4) " +
                            " GROUP BY year )", null)
                } catch (e: SQLiteException) {
                    return endSteps
                }
            }
        }

        if (cursor!!.moveToFirst()) {
            endSteps = cursor.getInt(cursor.getColumnIndex("maxSteps"))
        }

        cursor.close()
        return endSteps
    }



    // retrieve the total number of timeUnits when target steps was achieved
    fun getOnTarget(timeUnit: String, target: Int): Int {
        var endSteps = 0
        val db = writableDatabase
        var cursor: Cursor? = null

        when (timeUnit) {
            "days" -> {
                try {
                    cursor = db.rawQuery(
                            "SELECT count(date) AS onTarget, sumSteps FROM " +
                            "(SELECT date, SUM(" + DBContract.UserEntry.COLUMN_ENDSTEPS + " - " +
                            DBContract.UserEntry.COLUMN_STARTSTEPS + ") as sumSteps FROM " +
                            DBContract.UserEntry.TABLE_NAME  +
                            " GROUP BY " + DBContract.UserEntry.COLUMN_DATE + ") " +
                            "WHERE sumSteps > " + target, null)

                } catch (e: SQLiteException) {
                    return endSteps
                }
            }

            "weeks"-> {
                try {
                    cursor = db.rawQuery(
                            "SELECT count(week) AS onTarget, sumSteps FROM " +
                            "(SELECT SUM(" + DBContract.UserEntry.COLUMN_ENDSTEPS + " - " +
                            DBContract.UserEntry.COLUMN_STARTSTEPS + ") AS sumSteps, " +
                            " CAST(STRFTIME('%W', DATE(SUBSTR(" + DBContract.UserEntry.COLUMN_DATE + ", 1, 4) || '-'" +
                            " || SUBSTR(" + DBContract.UserEntry.COLUMN_DATE + ", 5, 2) || '-'" +
                            " || SUBSTR(" + DBContract.UserEntry.COLUMN_DATE + ", 7, 2))) AS int) AS week " +
                            " FROM " + DBContract.UserEntry.TABLE_NAME +
                            " GROUP BY week )" +
                            "WHERE sumSteps > " + target, null)
                } catch (e: SQLiteException) {
                    return endSteps
                }
            }
            "months" -> {
                try {
                    cursor = db.rawQuery(
                            "SELECT count(month) AS onTarget, sumSteps FROM " +
                            "(SELECT SUM(" + DBContract.UserEntry.COLUMN_ENDSTEPS + " - " +
                            DBContract.UserEntry.COLUMN_STARTSTEPS + ") AS sumSteps, " +
                            " CAST(SUBSTR(" + DBContract.UserEntry.COLUMN_DATE + ", 5, 2) AS INT) AS month " +
                            " FROM " + DBContract.UserEntry.TABLE_NAME +
                            " GROUP BY month )" +
                            "WHERE sumSteps > " + target, null)
                } catch (e: SQLiteException) {
                    return endSteps
                }
            }
            "years" -> {
                try {
                    cursor = db.rawQuery(
                        "SELECT count(year) AS onTarget, sumSteps FROM " +
                                "(SELECT SUM(" + DBContract.UserEntry.COLUMN_ENDSTEPS + " - " +
                                DBContract.UserEntry.COLUMN_STARTSTEPS + ") AS sumSteps, " +
                                " CAST(SUBSTR(" + DBContract.UserEntry.COLUMN_DATE + ", 1, 4) AS INT) AS year " +
                                " FROM " + DBContract.UserEntry.TABLE_NAME +
                                " GROUP BY year )" +
                                "WHERE sumSteps > " + target, null)
                } catch (e: SQLiteException) {
                    return endSteps
                }
            }
        }

        if (cursor!!.moveToFirst()) {
            endSteps = cursor.getInt(cursor.getColumnIndex("onTarget"))
        }

        cursor.close()
        return endSteps
    }



    fun readAllSteps(): ArrayList<StepsModel> {
        val steps = ArrayList<StepsModel>()
        val db = writableDatabase
        var cursor: Cursor? = null
        try {
            cursor = db.rawQuery("select * from " + DBContract.UserEntry.TABLE_NAME, null)
        } catch (e: SQLiteException) {
            db.execSQL(SQL_CREATE_ENTRIES)
            return ArrayList()
        }

        var stepsId: Int
        var date: Int
        var time: Int
        var startSteps: Int
        var endSteps: Int
        if (cursor!!.moveToFirst()) {
            while (cursor.isAfterLast == false) {
                stepsId = cursor.getInt(cursor.getColumnIndex(DBContract.UserEntry.COLUMN_DATE_ID))
                date = cursor.getInt(cursor.getColumnIndex(DBContract.UserEntry.COLUMN_DATE))
                time = cursor.getInt(cursor.getColumnIndex(DBContract.UserEntry.COLUMN_TIME))
                startSteps = cursor.getInt(cursor.getColumnIndex(DBContract.UserEntry.COLUMN_STARTSTEPS))
                endSteps = cursor.getInt(cursor.getColumnIndex(DBContract.UserEntry.COLUMN_ENDSTEPS))

                steps.add(StepsModel(stepsId, date, time, startSteps, endSteps))
                cursor.moveToNext()
            }
        }

        cursor.close()
        return steps
    }



    companion object {
        // If change in database schema, must increment the database version.
        val DATABASE_VERSION = 1
        val DATABASE_NAME = "paseoDB.db"

        private val SQL_CREATE_ENTRIES =
                "CREATE TABLE " + DBContract.UserEntry.TABLE_NAME + " (" +
                        DBContract.UserEntry.COLUMN_DATE_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                        DBContract.UserEntry.COLUMN_DATE + " TEXT," +
                        DBContract.UserEntry.COLUMN_TIME + " TEXT," +
                        DBContract.UserEntry.COLUMN_STARTSTEPS + " TEXT," +
                        DBContract.UserEntry.COLUMN_ENDSTEPS + " TEXT)"

        private val SQL_DELETE_ENTRIES = "DROP TABLE IF EXISTS " + DBContract.UserEntry.TABLE_NAME
    }
}
