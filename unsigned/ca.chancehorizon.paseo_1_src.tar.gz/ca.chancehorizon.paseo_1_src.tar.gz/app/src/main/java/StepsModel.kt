package ca.chancehorizon.paseo


class StepsModel(val _id: Int, val date: Int, val hour: Int, val startSteps: Int, val endSteps: Int)

